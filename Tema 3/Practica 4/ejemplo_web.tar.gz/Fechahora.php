<?php

function fecha($fecha) {
	return $fecha[8].$fecha[9]."/".
	       $fecha[5].$fecha[6]."/".
	       $fecha[0].$fecha[1].$fecha[2].$fecha[3];
}
?>
