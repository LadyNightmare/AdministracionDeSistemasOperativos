<?php
  $host = "localhost";
  $user = "usuario";
  $passwd = "usuario";
  $database = "fotovoltaica";
?>
